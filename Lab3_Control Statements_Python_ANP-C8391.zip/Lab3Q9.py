# Write a program to generate the following payslip for an employee:-

Employee_Name= input("Enter Your Name : ")
Basic_Salary = int(input("Enter Your Salary : "))
Experience= int(input("Enter Your Experience : "))

#Calculating Given Parameters
da= 0.05 * Basic_Salary
ta=0.065 * Basic_Salary
cca=0.08 * Basic_Salary
hra= 0.1 * Basic_Salary
pf=0.125 * Basic_Salary

# BONUS
bonus=0
if Experience>25 :
    bonus= 0.25 * Basic_Salary
elif 20<Experience<=25 :
    bonus= 0.2 * Basic_Salary
elif 15<Experience<=20 :
    bonus= 0.15 * Basic_Salary
elif 1<=Experience<=15 :
    bonus= 0.1 * Basic_Salary
else :
    print("Invalid Experience")

Total_Salary= Basic_Salary + da + ta + cca + hra + pf + bonus
Net_Salary= Total_Salary - pf

# Pay Slip
print("--------------------------------------------------------------------------------------------")
print("")
print("                                   Pay Slip")
print("")
print("--------------------------------------------------------------------------------------------")
print("")
print("NAME : ",Employee_Name)
print("EXPERIENCE : ",Experience)
print("BASIC SALARY : ",Basic_Salary)
print("")
print("---------------------------------------------------------------------------------------------")
print("")
print("DA is : ",da)
print("TA is : ",ta)
print("CCA is : ",cca)
print("HRA is : ",hra)
print("PF is : ",pf)
print("BONUS is : ",bonus)
print("TOTAL SALARY = ",Total_Salary)
print("NET SALARY = ",Net_Salary)
print("")
print("---------------------------------------------------------------------------------------------")
