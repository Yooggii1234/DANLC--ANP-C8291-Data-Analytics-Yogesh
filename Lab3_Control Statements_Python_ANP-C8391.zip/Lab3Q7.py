num= int(input("Enter the Amount : "))
Remaining=num
Two_thousand=0
if num>=2000 :
    Two_thousand=int(num/2000)
    Remaining = num - Two_thousand*2000

Five_Hundred=0
if 500<=Remaining<2000 :
    Five_Hundred = int(Remaining/500)
    Remaining = Remaining - 500*Five_Hundred

Two_Hundred=0
if 200<=Remaining<500 :
    Two_Hundred= int(Remaining/200)
    Remaining = Remaining - 200*Two_Hundred

Hundred=0
if 100<=Remaining<200 :
    Hundred= int(Remaining/100)
    Remaining= Remaining - 100*Hundred

Fifty=0
if 50<=Remaining<100 :
    Fifty = int(Remaining/50)
    Remaining = Remaining - 50*Fifty

print("2000 Ruppes Note is : ",Two_thousand)
print("500 Ruppes Note is : ",Five_Hundred)
print("200 Ruppes Note is : ",Two_Hundred)
print("100 Ruppes Note is : ",Hundred)
print("50 Ruppes Note is : ",Fifty)


