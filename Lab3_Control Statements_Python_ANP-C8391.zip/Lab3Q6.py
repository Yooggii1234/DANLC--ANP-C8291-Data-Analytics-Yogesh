#  Input units of electricity from user and print the bill according to the following criteria
# a.    Less than 200 : no bill
# b.    Next 200-300  -   1.2/perunit       100*1
# c.     Next 300-400  -1.5/perunit           100*2
# d.    Next 400-500  - 2.5/perunit          100*3
# e.    Above 500 -   8/per unit

units=int(input("Enter the Units to generate the bill : "))
if units<200 :
    bill="No bill"
elif 200<=units<300 :
    bill=(units-200)*1.2
elif 300<=units<400 :
    bill=(units-200)*1.5
elif 400<=units<500 :
    bill=(units-200)*2.5
else :
    bill=(units-200)*8
print("Electricity Bill is : ",bill)