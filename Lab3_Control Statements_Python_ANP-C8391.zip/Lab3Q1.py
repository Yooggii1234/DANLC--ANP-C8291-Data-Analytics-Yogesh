#  Wap to check whether a character is alphabet or not

char= input("Enter the Character : ")
if 65<ord(char)<=90 or 97<=ord(char)<=122 :
    print("Character is an Alphabet")
else :
    print("Character is not an Alphabet")
