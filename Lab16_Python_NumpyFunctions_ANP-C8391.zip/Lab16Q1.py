# 1. Suppose you have a dataset containing daily temperature readings for a city, and you want to identify days
# with extreme temperature conditions.Find days where the temperature either exceeded 35 degrees Celsius (hot day) or dropped below 5 degrees Celsius (cold day).
# Input: temperatures = np.array([32.5, 34.2, 36.8, 29.3, 31.0, 38.7, 23.1, 18.5, 22.8, 37.2])

import numpy as np

temperatures = np.array([32.5, 34.2, 36.8, 29.3, 31.0, 38.7, 23.1, 18.5, 22.8, 37.2])
print("Hot Days:")
Temperature = temperatures[(temperatures > 35)]
Day = np.argwhere(temperatures > 35).flatten()
df = dict((i, j) for i, j in zip(Day, Temperature))
print("Day  Temperature(\u00b0C)")
for key, value in df.items():
    print(f"{key}     {value}")
print()

temperatures = np.array([32.5, 34.2, 36.8, 29.3, -4, 38.7, 23.1, -18.5, 22.8, 37.2])
print("Cold Days:")
temperature = temperatures[(temperatures < 5)]
day = np.argwhere(temperatures < 5).flatten()
df2 = dict((i, j) for i, j in zip(day, temperature))
print("Day  Temperature(\u00b0C)")
for key, value in df2.items():
    print(f"{key}     {value}")
