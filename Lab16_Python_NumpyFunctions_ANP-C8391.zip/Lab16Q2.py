# Suppose you have a dataset containing monthly sales data for a company, and you
# want to split this data into quarterly reports for analysis and reporting purposes.
# Input: monthly_sales = np.array([120, 135, 148, 165, 180, 155, 168, 190, 205, 198, 210, 225])

import numpy as np

monthly_sales = np.array([120, 135, 148, 165, 180, 155, 168, 190, 205, 198, 210, 225])
splitted = np.split(monthly_sales, 4)

count = 1
for i in splitted:
    print(f"Quarter {count} sales (in thousand )")
    print(i)
    count += 1
