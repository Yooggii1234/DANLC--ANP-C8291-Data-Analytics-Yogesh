# Calculate the total cost of items in a shopping cart, considering the quantity and price per item.
# Input: quantity = np.array([2, 3, 4, 1])
#        price_per_item = np.array([10.0, 5.0, 8.0, 12.0])

import numpy as np

quantity = np.array([2, 3, 4, 1])
price_per_item = np.array([10.0, 5.0, 8.0, 12.0])

Total_Cost_per_Item = quantity * price_per_item

print("Total Cost of Items:", Total_Cost_per_Item)
