# Suppose you have a CSV file named 'house_prices.csv' with price information, and
# you want to perform the following operations:
#  1.Read the data from the CSV file into a NumPy array.
#  2.Calculate the average of house prices.
#  3.Identify house price above the average.
#  4.Save the list of high prices to a new CSV file.
import numpy as np
House_Price = np.genfromtxt('house_prices.csv', delimiter=',')
print(House_Price)
House_Price = np.delete(House_Price, 0)
print(f"After Delete : {House_Price}")

Average_Price = np.mean(House_Price)
print(f"Average of House Prices : {House_Price}")
print()

High_Prices = House_Price[House_Price > Average_Price]
print(f"House Price above the Average : {High_Prices}")
np.savetxt('high_price.csv', High_Prices, delimiter=',')
