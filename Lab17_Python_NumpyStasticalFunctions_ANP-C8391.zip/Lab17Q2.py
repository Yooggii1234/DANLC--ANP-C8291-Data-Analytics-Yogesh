# Compute the median of the flattened NumPy array
# Input: x_odd = np.array([1, 2, 3, 4, 5, 6, 7])

import numpy as np

x_odd = np.array([1, 2, 3, 4, 5, 6, 7])

array_median = np.median(x_odd)
print("Original Array : ", x_odd)
print("The Median of Flattened array is : ", array_median)