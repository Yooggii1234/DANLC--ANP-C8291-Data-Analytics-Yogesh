# Compute the standard deviation of the NumPy array
# Input: arr = [20, 2, 7, 1, 34]

import numpy as np

arr = [20, 2, 7, 1, 34]

std_dev = np.std(arr)
std_dev32 = np.std(arr, dtype=np.float32)
std_dev64 = np.std(arr, dtype=np.float64)

print("arr : ", arr, "\nStandard deviation of array : ", std_dev)
print("More precision with flot32\nStandard Deviation of array : ", std_dev32)
print("More Accuracy with float64\nStandard Deviation of array : ", std_dev64)
