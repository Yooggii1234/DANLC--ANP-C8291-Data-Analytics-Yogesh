# Create a bar chart to represent monthly expenses in different spending
# categories and give your conclusion.

import matplotlib.pyplot as plt

x = ['Rent', 'Groceries', 'Utilities', 'Entertainment', 'Transportation']
y = [1200, 400, 200, 150, 250]

plt.bar(x, y, color='lightblue')
plt.xlabel("Expense Category")
plt.ylabel("Monthly Expenses(USD)")
plt.title("Monthly Expense Breakdown")

plt.show()