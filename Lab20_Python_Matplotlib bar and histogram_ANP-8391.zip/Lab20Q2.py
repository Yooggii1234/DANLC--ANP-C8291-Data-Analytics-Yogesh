# Create a line plot to visualize the daily closing prices of a stock over a year
# and give your conclusion.

import matplotlib.pyplot as plt

x = list(range(1, 78))
y = [100, 105, 110, 115, 112, 120,
     118, 125, 128, 130, 132, 135,
     138, 140, 142, 144, 145, 148,
     150, 155, 160, 158, 162, 165,
     170, 172, 175, 178, 180, 182,
     185, 188, 190, 192, 195, 198,
     200, 198, 195, 193, 190, 188,
     185, 182, 180, 178, 175, 172,
     170, 168, 165, 162, 160, 158,
     155, 152, 150, 148, 145, 143,
     140, 138, 135, 132, 130, 128,
     125, 123, 120, 118, 115, 112,
     110, 108, 105, 103, 100]

plt.plot(x, y, color="blue")
plt.xlabel("Days of the year")
plt.ylabel("Stock Price(USD)")
plt.title("Stock over a Year")
plt.plot(x, y, marker="o")

plt.show()
