# Suppose I am a teacher, and I want to analyze the exam scores of my students
# to understand how they performed on a recent math test. I have collected the exam
# scores, and I want to create a histogram to visualize the distribution of scores.
# [Note: You need to share the exam scores in list format. For eg.22,45,60,75,80]

import matplotlib.pyplot as plt

exam_scores = [22, 35, 40, 45, 60, 75, 80, 55, 70, 90, 85, 95]

plt.hist(exam_scores, color='lightblue', edgecolor='red')
plt.title('Distribution of Math Exam Scores')
plt.xlabel('Scores')
plt.ylabel('Number of Students')

plt.show()
