# Write a Pandas program to get the first 3 rows of a given DataFrame.
# Sample DataFrame: exam_data = {'name': ['Anastasia', 'Dima', 'Katherine', 'James', 'Emily', 'Michael', 'Matthew',
#                                         'Laura', 'Kevin', 'Jonas'],
#                                'score': [12.5, 9, 16.5, np.nan, 9, 20, 14.5, np.nan, 8, 19],
#                                'attempts': [1, 3, 2, 3, 2, 3, 1, 1, 2, 1],
#                                'qualify': ['yes', 'no', 'yes', 'no', 'no', 'yes', 'yes', 'no', 'no', 'yes']}

import pandas as pd
import numpy as np

exam_data = {'name': ['Anastasia', 'Dima', 'Katherine', 'James', 'Emily',
                      'Michael', 'Matthew', 'Laura', 'Kevin', 'Jonas'],
             'score': [12.5, 9, 16.5, np.nan, 9, 20, 14.5, np.nan, 8, 19],
             'attempts': [1, 3, 2, 3, 2, 3, 1, 1, 2, 1],
             'qualify': ['yes', 'no', 'yes', 'no', 'no', 'yes', 'yes', 'no', 'no', 'yes']}


University_ID = [21068, 21079, 21099, 21088, 21045, 21138, 21146, 21169, 21179, 21197]

df = pd.DataFrame(exam_data,University_ID)
rows = df.head(3)

print("First Three Rows of Data Frame : \n ", rows)
