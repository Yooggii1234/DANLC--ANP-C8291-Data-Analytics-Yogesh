# Suppose you work for a retail company, and you have a dummy dataset containing sales data for the past year. The data
# includes information such as customer names, product names, sales quantities, prices, and dates. You want to perform
# various data analysis tasks like Total revenue for the year,Average revenue per sale,Best-selling product,Date with
# the highest total revenue also wants to generate product and total sales wise barchart using Pandas DataFrames.

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

data = {'Customer': ['Alice', 'Bob', 'Charlie', 'David', 'Eve', 'Frank', 'Grace', 'Hannah', 'Ivy', 'Jack'],
        'Product': ['Laptop', 'Smartphone', 'Tablet', 'Laptop', 'Smartphone', 'Tablet', 'Laptop', 'Smartphone', 'Tablet', 'Laptop'],
        'Quantity': [1, 2, 3, 1, 1, 2, 1, 3, 1, 1],
        'Price': [1000, 500, 300, 1000, 500, 300, 1000, 500, 300, 1000],
        'Date': pd.to_datetime(['2023-01-15', '2023-01-20', '2023-02-14', '2023-02-18', '2023-03-10',
                            '2023-03-22', '2023-04-05', '2023-04-15', '2023-05-01', '2023-05-20'])}

df = pd.DataFrame(data)

df['Revenue'] = df['Quantity'] * df['Price']
total_revenue = df['Revenue'].sum()


average_revenue_per_sale = df['Revenue'].mean()

product_sales = df.groupby('Product')['Quantity'].sum()
best_selling_product = product_sales.idxmax()

date_revenue = df.groupby('Date')['Revenue'].sum()
date_highest_revenue = date_revenue.idxmax()

print(f"Total Revenue for the Year: ${total_revenue:.2f}")
print(f"Average Revenue per Sale: ${average_revenue_per_sale:.2f}")
print(f"Best-Selling Product: {best_selling_product}")
print(f"Date with the Highest Total Revenue: {date_highest_revenue.date()}")

plt.figure(figsize=(14, 6))

plt.subplot(1, 2, 1)
product_sales.plot(kind='bar', color='skyblue')
plt.title('Total Sales by Product')
plt.xlabel('Product')
plt.ylabel('Total Quantity Sold')

date_revenue.plot(kind='bar', color='lightgreen')
plt.title('Total Revenue by Date')
plt.xlabel('Date')
plt.ylabel('Total Revenue ($)')

plt.tight_layout()
plt.show()

