# Write a NumPy program to create an array of 10 zeros, 10 ones, and 10 fives

import numpy as np

zeros = np.array([0.]*10)
ones = np.array([1.]*10)
fives = np.array([5.]*10)
print("An array of 10 zeros:\n ", zeros)
print("An array of 10 ones:\n", ones)
print("An array of 10 fives:\n", fives)
