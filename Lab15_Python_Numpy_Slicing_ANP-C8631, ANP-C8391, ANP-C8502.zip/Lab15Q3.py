# Write a NumPy program to create an array with values ranging from 12 to 38

import numpy as np

array = np.arange(12, 39)
print(array)
