# Scenario: Analyzing Stock Prices
# Suppose you are an investor interested in analyzing the stock prices of a particular
# company over a year. You have collected daily closing prices for that company's stock,
# and you want to perform some analysis like Calculate the average daily return,Find the
# date with the highest closing price and also generate a line chart using Pandas Series.

import pandas as pd
import matplotlib.pyplot as plt

dates = pd.date_range(start="2023-01-01", periods=365, freq='D')
closing_prices = [150 + i*0.1 for i in range(365)]  # Example: incremental prices
data = pd.Series(data=closing_prices, index=dates, name='Close')

daily_returns = data.pct_change()
average_daily_return = daily_returns.mean()
print(f"Average Daily Return: {average_daily_return:.4%}")

max_price_date = data.idxmax()
max_price = data.max()
print(f"Date with the highest closing price: {max_price_date}")
print(f"Highest Closing Price: ${max_price:.2f}")

plt.figure(figsize=(10, 6))
data.plot(title='Stock Closing Prices Over Time')
plt.xlabel('Date')
plt.ylabel('Closing Price')
plt.grid(True)
plt.show()
