import pandas as pd
import matplotlib.pyplot as plt

data = {'Date': pd.date_range(start='2023-01-01', periods=10, freq='D'),
        'Open': [500, 505, 510, 515, 520, 525, 530, 535, 540, 545],
        'Close': [505, 510, 515, 520, 525, 530, 535, 540, 545, 550]}

df = pd.DataFrame(data)
df.set_index('Date', inplace=True)

start_date = '2023-01-03'
end_date = '2023-01-08'

filtered_df = df.loc[start_date:end_date]

plt.figure(figsize=(10, 6))
plt.plot(filtered_df.index, filtered_df['Open'], label='Opening Price', marker='o')
plt.plot(filtered_df.index, filtered_df['Close'], label='Closing Price', marker='x')
plt.title('SBI Stock Prices')
plt.xlabel('Date')
plt.ylabel('Price')
plt.legend()
plt.grid(True)
plt.show()
