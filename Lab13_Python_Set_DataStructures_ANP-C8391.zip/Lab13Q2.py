# Write a Python program to Return a set of elements present in Set A or B, but not both.
# Input: set1 = {10, 20, 30, 40, 50}
#        set2 = {30, 40, 50, 60, 70}

set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}
unique_elements = (set1 | set2) - (set1 & set2)
print("The Elements Present in Set A or B,but not in both is : ", unique_elements)