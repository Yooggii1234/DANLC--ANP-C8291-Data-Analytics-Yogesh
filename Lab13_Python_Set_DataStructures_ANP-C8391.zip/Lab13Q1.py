# Write a Python program to Get Only unique items from two sets.
# Input: set1 = {10, 20, 30, 40, 50}
#        set2 = {30, 40, 50, 60, 70}

set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}
Result_set = {}

Result_set = set1 | set2
print("Unique Items from Two set is : ", Result_set)