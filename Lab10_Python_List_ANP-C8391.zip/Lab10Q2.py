# Write a Python program to get the largest and smallest number from a list  without builtin functions

numbers = [67, 75, 85, 865, 856, 96, 84]
largest = numbers[0]
smallest = numbers[0]

for number in numbers:
    if number > largest:
        largest = number
    elif number < smallest:
        smallest = number

print(f"Largest number in a List is : {largest}")
print(f"Smallest number in a List is : {smallest}")
