# Write a Python program to traverse a given list in reverse order,
# and print the elements with the original index.
# Original list: ['red', 'green', 'white', 'black']

original_list = ['red', 'green', 'white', 'black']

reversed_list = original_list[::-1]

for element in reversed_list:
    print(element,end=" ")
