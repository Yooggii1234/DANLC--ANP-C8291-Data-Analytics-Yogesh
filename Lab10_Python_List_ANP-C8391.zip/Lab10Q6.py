# Given the nested list 'matrix = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]'
# Write code to print the second element of the first list and the third element of the third list.

matrix = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
print("Second Element of First List is : ", matrix[0][1])
print("Third Element of Third list is : ", matrix[2][2])
