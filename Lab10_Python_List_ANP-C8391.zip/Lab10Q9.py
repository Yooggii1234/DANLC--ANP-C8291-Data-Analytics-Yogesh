# Given two lists `a = [1, 2, 3]` and `b = [4, 5, 6]`, write code to merge them into a single list and
# then flatten a list of lists `c = [[1, 2], [3, 4], [5, 6]]` into a single list.

a = [1, 2, 3]
b = [4, 5, 6]
merge_list = a + b
print("Merged List is : ", merge_list)

c = [[1, 2], [3, 4], [5, 6]]
flatten_list = []
for sublist in c:
    for i in sublist:
        flatten_list.append(i)
print("Flatten List is : ",flatten_list)


