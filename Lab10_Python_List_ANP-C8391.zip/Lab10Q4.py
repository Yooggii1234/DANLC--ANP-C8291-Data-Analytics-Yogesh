# Write a Python program to split a given list into two parts where :
# the length of the first part of the list is given. (Length of the first part of the list: 3 )
# Original list: [1, 1, 2, 3, 4, 4, 5, 1]

Original_list = [1, 1, 2, 3, 4, 4, 5, 1]
Length_of_first_part_split = 3

first_part = Original_list[:Length_of_first_part_split]
Second_part = Original_list[Length_of_first_part_split:]

print("Split the said list into two parts : ", (first_part, Second_part))

