# Write a function `rotate_list(lst, k)` that rotates a list to the right by `k` positions.
# For example, `rotate_list([1, 2, 3, 4, 5], 2)` should return `[4, 5, 1, 2, 3]

def rotate_list(lst,k):
    a = len(lst)
    temp = lst[-k:]

    for i in range(a-1, k-1,-1):
        lst[i] = lst[i-k]

    lst[:k] = temp
    return lst
List_1 = []
size = 5
for _ in range(size):
    List_1.append(int(input("Enter the Numbers : ")))
k = 2

print("The Rotated List is : ", rotate_list(List_1,k))

