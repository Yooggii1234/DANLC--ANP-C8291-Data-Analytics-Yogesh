# Given the list `numbers = [15, 3, 7, 20, 13, 9, 25, 1, 10]`,
# write a list comprehension to create a new list containing only the even numbers.

numbers = [15, 3, 7, 20, 13, 9, 25, 1, 10]
even_number_list =[]

for element in numbers:
    if element % 2 == 0:
        even_number_list.append(element)
print("The Even numbers in the original list is : ", even_number_list)