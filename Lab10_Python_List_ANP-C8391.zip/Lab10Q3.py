# Write a Python program to find duplicate values from a list and display those

my_list = [675, 757, 875, 865, 856, 960, 844, 757, 667, 960, 996]
duplicates = []

for item in my_list:
    if my_list.count(item) > 1 and item not in duplicates:
        duplicates.append(item)

print("Duplicate values in List are : ", duplicates)
