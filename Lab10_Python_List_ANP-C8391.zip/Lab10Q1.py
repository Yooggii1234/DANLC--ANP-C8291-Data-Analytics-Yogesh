# Write a Python program to sum all the items in a list

my_list = [67, 75, 85, 865, 856, 96, 84, 45, 24]
sum_item = 0
for i in my_list:
    sum_item = sum_item + i
print(sum_item)