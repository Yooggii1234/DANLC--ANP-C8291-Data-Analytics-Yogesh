# Write a Python program to convert a list to a tuple.
# Input: listx = [5, 10, 7, 4, 15, 3]

listx = [5, 10, 7, 4, 15, 3]
tuple = ()

for i in listx:
    tuple = tuple + (i,)
print("The converted tuple is : ", tuple)