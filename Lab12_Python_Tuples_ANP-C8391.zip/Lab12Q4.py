# Write a python program and iterate the given tuples
# Input: employee1 = ("John Doe", 101, "Human Resources", 60000)
#        employee2 = ("Alice Smith", 102, "Marketing", 55000)
#        employee3 = ("Bob Johnson", 103, "Engineering", 75000)

employee1 = ("John Doe", 101, "Human Resources", 60000)
employee2 = ("Alice Smith", 102, "Marketing", 55000)
employee3 = ("Bob Johnson", 103, "Engineering", 75000)
list = [employee1, employee2, employee3]

for i in list:
    Name = i[0]
    Employee_ID = i[1]
    Department = i[2]
    Salary = i[3]
    print(f"Name : ", Name)
    print(f"Employee ID : ", Employee_ID)
    print(f"Department : ", Department)
    print(f"Salary : ", Salary)
    print("----------------------------------------------------------------")
