# Write a Python program to calculate the sum of the numbers in a given tuple.
# Input: tuples_list = [(1, 2), (3, 4), (5, 6)]

tuples_list = [(1, 2), (3, 4), (5, 6)]
tuplex = ()
for i in tuples_list:
    tuplex = tuplex + i
print(tuplex)
sum = 0
for j in tuplex:
    sum = sum + j
print("The Sum of Numbers in tuple is : ", sum)

