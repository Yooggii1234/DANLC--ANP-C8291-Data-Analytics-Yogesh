# Write a Python program to get the key, value and item in a dictionary.
# Original Dictionary =  {1: 10, 2: 20, 3: 30, 4: 40, 5: 50, 6: 60}
# Input: input_dict = {1: 10, 2: 20, 3:None, 4: 40, 5: None, 6: 60}

input_dict = {1: 10, 2: 20, 3: None, 4: 40, 5: None, 6: 60}
Output_dict = {}

for key, value in input_dict.items():
    if value is not None:
        Output_dict[key] = value

print("Dictionary with Empty Items Dropped : ", Output_dict)

