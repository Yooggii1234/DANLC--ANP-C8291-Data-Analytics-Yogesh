# Write a Python script to concatenate the following dictionaries to create a new one.
# Sample Dictionary :
# dic1={1:10, 2:20}
# dic2={3:30, 4:40}
# dic3={5:50,6:60}

dic1 = {1: 10, 2: 20}
dic2 = {3: 30, 4: 40}
dic3 = {5: 50, 6: 60}
concatenate_dict = {}
concatenate_dict.update(dic1)
concatenate_dict.update(dic2)
concatenate_dict.update(dic3)
print("The New dictionary is : ", concatenate_dict)
