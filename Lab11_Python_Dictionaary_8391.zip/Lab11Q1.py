# Write a Python program and calculate the mean of the below dictionary.
# test_dict = {"A" : 6, "B" : 9, "C" : 5, "D" : 7, "E" : 4}

test_dict = {"A": 6, "B": 9, "C": 5, "D": 7, "E": 4}

count = len(test_dict)
mean = sum(test_dict.values())/count

print("The mean of the Dictionary is : ", mean)
