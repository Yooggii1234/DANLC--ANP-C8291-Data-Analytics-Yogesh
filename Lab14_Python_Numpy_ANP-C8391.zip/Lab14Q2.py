#  Convert the below list into a numpy array then display the array then display the first and last index
#  and then multiply each element by 2 and display the result.
#  Input: my_list = [1, 2, 3, 4, 5]

import numpy as np

my_list = [1, 2, 3, 4, 5]

converted_array = np.array(my_list)
print("Array : ", converted_array)

element1 = converted_array[0]
element2 = converted_array[-1]

print(f"The Elements on first and last index of array is {element1} and {element2} ")

result = converted_array * 2
print("The array after multiplying each element by 2 is : ", result)
