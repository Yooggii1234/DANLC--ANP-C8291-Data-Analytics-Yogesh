# Convert the below list into numpy array then display the array
#  Input: my_list = [1, 2, 3, 4, 5]

import numpy as np

my_list = [1, 2, 3, 4, 5]

numpy_array = np.array(my_list)

print("Converted Numpy Array : ", numpy_array)
