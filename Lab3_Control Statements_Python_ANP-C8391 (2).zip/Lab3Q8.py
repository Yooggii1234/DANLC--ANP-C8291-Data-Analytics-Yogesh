#  input bank login and password and check whether it is valid or not and
#  if login is successful, then give options to user for the following:-
#  1. Change password
#  2. Check Balance
#  3. Deposit Amount
#  4. Withdraw Amount

UserID= "bangariyogesh2003@gmail.com"
UserPass="Yogi@7838"

uid=input("Enter the User ID : ")
if uid==UserID :
    upass=input("Enter your password : ")
    if upass==UserPass :
        print("Login Succesfully")
        print("1.Change Password")
        print("2.Check Balance")
        print("3.Deposit Amount")
        print("4.Withdraw Amount")
        option= int(input("Enter the number between 1 to 4 : "))
        if option==1 :
            print("Enter your new password")
        elif option==2 :
                print("Your Balance is 37832")
        elif option==3 :
                print("Enter Deposit Amount")
        elif option==4 :
                print("Enter Withdraw Amount")
        else :
            print("Invalid Option")
    else :
        print("Incorrect Password")
else :
    print("Invalid User ID")

