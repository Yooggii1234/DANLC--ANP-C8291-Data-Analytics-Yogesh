#  Input units of electricity from user and print the bill according to the following criteria
# a.    Less than 200 : no bill
# b.    Next 200-300  -   1.2/per unit       100*1
# c.     Next 300-400  -1.5/per unit           100*2
# d.    Next 400-500  - 2.5/per unit          100*3
# e.    Above 500 -   8/per unit

unit = float(input("Enter units of electricity"))
bill = 0;
if unit<200:
    print("No bill")
elif unit<=300:
    bill = (unit - 200) * 1.2
elif unit<=400:
    bill = (100*1.2)+((unit-300)*1.5)
elif unit<=500:
    bill = (100*1.2)+(100*1.5)+(unit-400)*2.5
else:
    bill = (100*1.2)+(100*1.5)+(100*2.5)+(unit-500)*8

print(f"The Electricity bill for {unit} is {bill}")