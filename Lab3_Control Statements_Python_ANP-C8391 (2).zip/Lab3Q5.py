char = input("Enter the Character : ")
if 65<ord(char)<=90 or 97<=ord(char)<=122 :
    print("It is an Alphabet")
elif 48<=ord(char)<=57 :
    print("It is a Number")
elif 33<=ord(char)<=47 :
    print("It is a Special Character")
else :
    print("It is an invalid character")