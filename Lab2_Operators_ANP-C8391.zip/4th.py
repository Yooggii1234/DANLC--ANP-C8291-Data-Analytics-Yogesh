# Wap to check whether a character is alphabet or not
char= input("Enter a character : ")
result= "It is an Alphabet" if 65<ord(char)<=90 or 97<=ord(char)<=122 else "It is not an Alphabet"
print(result)