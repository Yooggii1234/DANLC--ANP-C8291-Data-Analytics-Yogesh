# Wap to check whether a character is  in lower case or upper case
# A-Z  : 65 to 90
# a-z  : 97 to 122

char=input("Enter a letter :")
result= "Upper Case" if 65<=ord(char)<=90 else "Lower Case"
print(result)
